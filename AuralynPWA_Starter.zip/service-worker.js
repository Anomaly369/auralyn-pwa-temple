
self.addEventListener('install', event => {
  console.log('Auralyn Temple Service Worker installed.');
});

self.addEventListener('fetch', event => {
  // Default fetch behavior
});
